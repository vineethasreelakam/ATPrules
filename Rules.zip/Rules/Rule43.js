import React from 'react';
import { Text, View, Image, ScrollView } from 'react-native';
import { RuleStyles } from './Styles.js';
import RuleNavigationButtons from '../screens/RuleNavigationButtons.js';
import ImageViewerComponent from '../screens/ImageViewerComponent.js';

export default function Rule43({ navigation }) {
  return (
    <>
      <View style={RuleStyles.Layout}>
        <ScrollView style={RuleStyles.ScrollViewStyle} minimumZoomScale={1} maximumZoomScale={10}>
          <Text style={RuleStyles.MainHeading}>III. FINANCIAL</Text>
          <ImageViewerComponent props={{ImageStyle:RuleStyles.ImageStyle, ImageName: 'rule2.png'}}/>
          <Text style={RuleStyles.Description}>
            <Text style={RuleStyles.SubHeading1}>3.19 ATP 500 and ATP 250 Tournament Financial
              Information</Text>{'\n\n'}

            <Text style={RuleStyles.SubHeading2}>A. </Text>
            Each 500 and 250 category tournament member is required to annually provide to
            the PM Committee Auditor (as defined below) a complete and accurate determination
            and calculation of its actual tournament Gross Revenues (as defined below), costs,
            expenses and net income and all other financial information and supporting documentation
            relating thereto, in each case, as requested by the PM Committee Auditor
            and in accordance with the terms of this rule. In connection with the foregoing, each
            500 and 250 category tournament member shall provide its full cooperation to the
            PM Committee Auditor, who will examine and verify the accuracy of such information.{'\n\n'}

            <Text style={RuleStyles.SubHeading2}>B. </Text>
            The following terms shall have the meanings set forth below:{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>“Prize Money Committee (PM Committee)”</Text>
            means the committee appointed by
            the ATP Board of Directors and authorized to act in accordance with this rule, which
            shall be comprised of the ATP Chairman or his designee, an Independent Member
            (as defined below) and an equal number of tournament and player representatives,
            with only one (1) tournament representative and one (1) player representative serving on
            such PM Committee, being designated by the class of ATP Board Directors
            that appointed such representatives, with the right to vote on any PM Committee
            matters, regardless of the number of tournament and player representatives appointed to
            serve on the PM Committee. The player representative and the tournament
            representative designated with the right to vote on PM Committee matters shall be
            collectively referred to herein as the “Voting Members”.{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>“PM Committee Auditor” </Text>
            means an independent accounting firm appointed by the
            PM Committee to (i) receive and evaluate each tournament member’s Submissions
            and projected tournament financials, (ii) perform agreed upon procedures regarding
            financial information included in each Submission, and (iii) prepare reports to be
            provided to the PM Committee and to the ATP Board of Directors in accordance with
            this rule summarizing the Submissions. The PM Committee Auditor will also act as
            advisor to the Committee on financial and accounting related matters and Gross
            Revenue, costs, expenses and net income reporting issues and questions.{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>“Independent Member” </Text>
            means the independent member of the PM Committee appointed by the
            ATP Board of Directors, by the affirmative vote of at least two Player
            Board Representatives and two Tournament Board Representatives, to serve on the
            PM Committee for a 3-year term. The Independent Member is subject to removal at
            any time by the ATP Board of Directors by the same vote required for appointment.{'\n\n'}


            <Text style={RuleStyles.SubHeading3}>“Player Auditor” </Text>
            means an independent certified public accountant and/or financial
            advisor selected by the player member(s) of the PM Committee and approved by the
            PM Committee in accordance with Section C below, who meets the appropriate level
            of expertise and experience to evaluate the accuracy of the Submissions. The Player
            Auditor will act as advisor to the player member(s) of PM Committee. The Player Auditor
            may also review items and information related to the application of the ATP prize
            money rules to the extent requested by the player member(s) of the PM Committee
            and shall provide comfort to such member(s) as to the accuracy of the Submissions
            to confirm the reasonableness of the PM Committee Auditor’s evaluation thereof.{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>“Gross Revenues” </Text>
            means the total amount of gross revenues related to a tournament
            determined on the basis of the Generally Accepted Accounting Principles in the
            United States (“GAAP”) or the International Financial Reporting Standards (“IFRS”)
            (depending on the applicable accounting rules in the country in which the tournament
            operates), in each case, as in effect on such date of determination and consistently
            applied, which shall include all revenues related to the tournament’s operations regardless
            of which entity affiliated with the tournament receives, or accounts for, such
            revenues or in which jurisdiction such revenues are reported. All such revenues shall
            be reported in the tournament’s domestic reporting currency. For men’s and women’s
            combined tournaments, total Gross Revenues should be broken out by tournament
            and categorized by those identifiable only to the men’s tournament, those identifiable
            only to the women’s tournament, and all other revenues. The PM Committee has
            the power to create additional rules for reporting Gross Revenues. Consistent with
            both GAAP and IFRS, tournaments will report estimated revenues for those revenue
            sources where final revenue amounts are not determinable by the deadline for completing
            the Submission. Subsequent adjustments of these estimates to actual will be
            included in Gross Revenues in the subsequent Submission when such final revenue
            amounts are known.{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>“Barter” </Text>
            a description of each Barter transaction must be included as part of each
            Submission. Barter transactions as defined below for each revenue category are
            required to be included in Gross Revenues. Barter for this purpose is non-cash transactions
            (for example advertising) where value is exchanged (for example, when cars
            are provided as part of a car sponsor deal the value of the cars provided must be
            included in sponsor revenues. Another example is tickets given to a local club or
            charity for no consideration would not be valued or included in ticketing revenues).
            Barter valuations should be in accordance with GAAP or IFRS applicable to each
            tournament. The PM Committee will work with the PM Committee Auditor and include
            a comprehensive definition of barter transactions and their valuation for Gross Revenue
            purposes and include such comprehensive definition as part of the Submission.
            The following Barter transactions are excluded from Gross Revenues:{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>(a) </Text>
            Media commitments for promotional time or space that are not for resale and are
            used solely (i) to promote the tournament, (ii) to promote the ATP or any related
            event or activity of the tournament that generates Gross Revenues, (iii) to promote
            charitable or not for profit organizations or agencies that are unrelated to
            the tournament or tournament affiliates, or (iv) for public service announcements.{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>(b) </Text>
            Any barter transaction that is both used to satisfy tournament standards and is
            for the direct benefit of the players. Such direct player benefits include, but are
            not limited to, hotel accommodations; player transportation, player food, meals
            and beverages; lounge for players; internet access for players; and gifting and
            on-court supplies for players.{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>(c) </Text>
            De Minimus barter transactions are defined as individual transactions with valuations
            under $10,000 for 250 tournaments and $20,000 for 500 tournaments. De
            Minimus transactions are not required to be reported individually in the Submission as
            long as the total of such individual transactions is 5% or less of Gross
            Revenues. In the event such total exceeds 5% of Gross Revenues, tournaments
            must individually report the highest valued barter transactions included in the total
            such that the total excluding those transactions is 5% or less of Gross Revenues.
            A summary written description of each De Minimus transaction is required to be
            included in the Submission.{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>“Submission” </Text>
            means the prescribed, mandatory annual financial information report
            required to be submitted hereunder to the PM Committee Auditor by each 500 and
            250 category tournament which, for the avoidance of doubt, shall include a determination
            and calculation of Gross Revenues, costs, expenses and net income, similar
            in detail to the prior Tournament Financial review process and any other information
            required or reasonably requested by the PM Committee. The Submission must be
            completed in full as determined by the PM Committee Auditor to be considered in
            compliance with this rule.{'\n\n'}

            <Text style={RuleStyles.SubHeading3}>“Related Party” </Text>
            means a person or company that has control, joint control or significant
            influence over the tournament or a tournament entity, either by ownership, by
            agreement, or by power to manage, govern or influence the tournament’s finances
            and/or operations. Also, a person or company is considered to be a related party to
            the tournament if the tournament has control, joint control or significant influence over
            the person or company, either by ownership, by agreement, or by power to manage,
            govern or influence the person or company’s finances and/or operations.{'\n\n'}

            <Text style={RuleStyles.SubHeading2}>C. </Text>
            The PM Committee will administer, implement and enforce this rule, including, but
            not limited to (i) determining procedures for audits for purposes of financial disclosures
            in accordance with the terms of this rule; (ii) determining the process of receiving
            financial information from tournament members and audits with respect to
            such information; (iii) evaluating and resolving questions and issues that may arise in
            respect of any audit, Submission or violation of this rule; (iv) enforcing this rule
            pursuant to Section F below; and (v) implementing any other aspect of this rule. All actions,
            approvals and determinations of the PM Committee shall require a unanimous vote
            of the Voting Members, unless otherwise expressly provided in this rule (including
            as set forth in Sections B, C, E and F below). The ATP Chairman shall have no
            right to vote on PM Committee matters; provided, however, that in the event that the
            Voting Members are unable to unanimously agree on the appointment of the Player
            Auditor, the ATP Chairman acting reasonably shall have the right to vote on whether
            approval of the proposed Player Auditor should be granted. If any such vote by the
            ATP Chairman votes against the approval of any proposed Player Auditor, then the
            ATP Chairman will provide a brief description of his or her reason for such decision to
            the PM Committee. The PM Committee will meet regularly as deemed necessary by
            the PM Committee to properly administer, implement and enforce this rule. The ATP
            Board of Directors will make reasonable and adequate funding available to enable
            to the PM Committee to administer, implement and enforce this rule in accordance
            with the terms herein.{'\n\n'}

            <Text style={RuleStyles.SubHeading2}>D. </Text>
            Each 500 and 250 category tournament member is required to provide a complete
            and accurate Submission annually to the PM Committee Auditor no later than 120
            days following the conclusion of its tournament for such year. Each Submission must
            be certified by the applicable tournament member as complete and accurate and in
            compliance with this rule in all material respects. The financial information included
            in each Submission shall be construed and prepared in accordance with GAAP
            or IFRS, unless a different basis is legally mandated by the country in which the
            tournament operates. In such case, differences between any such other basis and
            GAAP or IFRS, as applicable, must be identified and resolved by such tournament
            member as part of its Submission. Upon appointment by the PM Committee, each
            of the PM Committee Auditor and the Player Auditor will be instructed not to disclose
            any individual tournament information or documentation that it receives to any party,
            including the PM Committee, any of its members, the ATP Board of Directors, ATP or
            its staff, except for the ATP Chairman, CEO and CFO (or their respective reasonably
            appointed designees). The PM Committee Auditor and Player Auditor will be required
            to execute and deliver to the Committee a statement of confidentiality and non-disclosure
            prohibiting either the PM Committee Auditor or Player Auditor from making
            any such disclosure. Notwithstanding the foregoing, the PM Committee Auditor, the
            Player Auditor, the ATP Chairman, CEO and CFO (or their respective reasonably
            appointed designees) may share individual tournament information or documentation
            across the 500 category tournament members in an anonymized fashion.{'\n\n'}

            <Text style={RuleStyles.SubHeading2}>E. </Text>
            Each year, the PM Committee Auditor will perform an agreed upon desk-based procedures
            audit (as directed by the PM Committee) of each tournament’s Gross Revenues included in
            the Submission and report to the PM Committee any issues that it
            may identify as a result of these procedures for which the PM Committee Auditor is
            unable to resolve with the respective tournament. Once this process is complete, the
            PM Committee Auditor will provide the results of its procedures and the supporting
            audit work papers to the Player Auditor. The Player Auditor will undertake a review
            of the provided information and results. After completing this review, if the Player
            Auditor has any outstanding issues or questions, the Player Auditor will work with the
            PM Committee Auditor to resolve such issues and questions. In the event that the PM
            Committee Auditor and the Player Auditor are unable to resolve any such issues or
            questions, the Committee Auditor and the Player Auditor will inform the PM Committee
            and may jointly conduct an on-site audit at the offices of the relevant tournament
            or Related Party to review and evaluate the books and records of such tournament
            or Related Party that are reasonably necessary to resolve such issue or question;
            provided, that any such joint on-site audit must be conducted during regular business
            hours and no more than three (3) joint on-site audits may be conducted during any
            consecutive twelve (12) month period. If after any joint on-site audit, the PM Committee
            Auditor and the Player Auditor are still unable to resolve any such issues or
            questions (or in the event the PM Committee Auditor and the Player Auditor elect not
            to conduct an on-site audit and such issues or questions remain), the PM Committee
            Auditor and the Player Auditor will inform the PM
            Committee and the PM Committee will evaluate the information presented and then
            issue a determination as to whether the unresolved issue(s) or question(s) is due to
            an act or omission of a tournament member. In the event that the Voting Members are
            unable to unanimously agree on such determination, then the Independent Member
            will make such determination in his or her sole discretion. If it is determined that the
            unresolved issue(s) or questions(s) are due to an act or omission of a tournament
            member, then the revenues for that tournament could be excluded from the 500s
            prize money formula calculation and/or that tournament may be subject to a fine
            pursuant to Section F below.{'\n\n'}

            <Text style={RuleStyles.SubHeading2}>F. </Text>
            Any tournament member that (i) fails to provide a Submission to the PM Committee
            Auditor as required under this rule (including with respect to the timing, accuracy and/
            or completeness thereof), (ii) submits a report or document that contains a material
            misstatement or omits material information, (iii) does not fully cooperate with the PM
            Committee Auditor and Player Auditor as required hereunder, or (iv) otherwise fails
            to comply with this rule, may request from the PM Committee a 10 day extension in
            order to comply with its submission failure. Following any such extension the tournament
            in each case, may be subject to a fine in a maximum amount of $250,000. This
            maximum fine amount will increase by 100% for each consecutive year submission
            failure by a tournament. The PM Committee shall evaluate the circumstances that led
            to the failure of such tournament member to comply with the terms of this rule and assess
            an appropriate fine taking into consideration the guidelines set forth in Section G
            below or as otherwise provided by the ATP Board of Directors from time to time. For
            clarity, any such guidelines will be for guidance purposes only and the PM Committee
            will have the right to determine an appropriate fine in its sole discretion. In the event
            that the Voting Members are unable to unanimously agree on a fine, the Independent
            Member will make such determination in his or her sole discretion taking into account
            the circumstances that led to the failure of the tournament member to comply with
            the terms of this rule. All fines assessed under this rule will be contributed to player
            programs as determined by the Player Board Representatives.{'\n\n'}

            <Text style={RuleStyles.SubHeading2}>G. </Text>
            The following guidelines set forth fines that may be imposed for violations of this rule
            (subject to the discretion of Committee as set forth in this rule):{'\n\n'}




            *Specific amounts should depend on the severity of the violation and issue(s)
            presented.




            {'\n\n'}
          </Text>
        </ScrollView>
      </View>
      <RuleNavigationButtons props={{ prev: 'Rule42', next: 'Rule44', nav: navigation }} />
    </>
  );
}


import React from 'react';
import { Text, View, Image, ScrollView } from 'react-native';
import { RuleStyles } from './Styles.js';
import RuleNavigationButtons from '../screens/RuleNavigationButtons.js';
import ImageViewerComponent from '../screens/ImageViewerComponent.js';

export default function Rule45({ navigation }) {
  return (
    <>
      <View style={RuleStyles.Layout}>
        <ScrollView style={RuleStyles.ScrollViewStyle} minimumZoomScale={1} maximumZoomScale={10}>
          <Text style={RuleStyles.MainHeading}>III. FINANCIAL</Text>
          <ImageViewerComponent props={{ImageStyle:RuleStyles.ImageStyle, ImageName: 'rule2.png'}}/>
          <Text style={RuleStyles.Description}>
            <Text style={RuleStyles.SubHeading1}>3.21 250 Tournament Prize Money</Text>{'\n\n'}

            On-site prize money for 2023 is the amount approved by the ATP Board for each
            tournament.{'\n\n'}
            On site prize money for the 250 category tournaments will increase annually by 2.5%
            for the period 2024 through 2030. Such 2.5% annual increases in on site prize money
            will be calculated using the total of on-site prize money for all 250 tournaments and
            then divided equally among the tournaments.{'\n\n'}

            {'\n\n'}
          </Text>
        </ScrollView>
      </View>
      <RuleNavigationButtons props={{ prev: 'Rule44', next: 'Rule46', nav: navigation }} />
    </>
  );
}

